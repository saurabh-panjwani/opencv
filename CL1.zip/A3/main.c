#include<stdio.h>

int main() 
{
    int a = 1;
    printf("%d",a+5);
    return 0;
}


