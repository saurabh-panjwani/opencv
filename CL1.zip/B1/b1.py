import json
import numpy as np

inf=open("b1.json")
board=json.loads(inf.read())
board=board["matrix"]
print("board: ")
print(np.matrix(board))
#print(board)

def issafe(row,col):
        for i in range(8):
                for j in range(8):
                        if(board[i][j]==1):
                                if(row==i):
                                        return False
                                if(col==j):
                                        return False
                                if(abs(row-i)==abs(col-j)):
                                        return False
        return True
                
def isplace(col):
        if(col>=8):
                return True
                print("Completed \t \n")
        for i in range(8):
                if issafe(i,col):
                        board[i][col]=1
                        if(isplace(col+1)):
                                return True
                        board[i][col]=0
        return False
  
if(isplace(1)):
        print("Solution found")
        print(np.matrix(board))
        #print(board)
else:
        print("Solution not possible")
