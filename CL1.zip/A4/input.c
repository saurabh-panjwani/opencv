#include <stdio.h>
main()
{
	int a,b;
	if() {
		printf("Hi!\n");
	}
	printf("Hello World");
}
