import csv
import random
import math
import operator

def loadDataset(filename,split,trainingset=[],testset=[]):
        with open(filename,'r') as csvfile:
                lines=csv.reader(csvfile)
                dataset=list(lines)
                for x in range(len(dataset)-1):
                        for y in range(4):
                                dataset[x][y]=float(dataset[x][y])
                        if random.random() < split:
                                trainingset.append(dataset[x])
                        else:
                                testset.append(dataset[x])
                                
def getEuclideanDistance(traininginstance,testinstance,length):
        distance=0
        for x in range(length):
                distance+=pow((traininginstance[x]-testinstance[x]),2)
        distance=math.sqrt(distance)
        return distance
                                
def getNeighbour(testinstance,trainingset,k):
        distances=[]
        length=len(testinstance)-1
        for x in range(len(trainingset)):
                dist=getEuclideanDistance(trainingset[x],testinstance,length)
                distances.append((trainingset[x],dist))
        distances.sort(key=operator.itemgetter(1))
        neighbours=[]
        for x in range(k):
                neighbours.append(distances[x][0])
        return neighbours
        

def getResponse(neighbours):
        classVotes={}
        for x in range(len(neighbours)):
                response=neighbours[x][-1]
                if response in classVotes:
                        classVotes[response]+=1
                else:
                        classVotes[response]=1
        sortedVotes=sorted(classVotes.items(),key=operator.itemgetter(1),reverse=True)
        return sortedVotes[0][0]
        
def getAccuracy(predictions,testset):
        correct=0
        for x in range(len(testset)):
                if predictions[x]==testset[x][-1]:
                        correct+=1
        return (correct/float(len(testset)))*100.0

def main():
        trainingset=[]
        testset=[]
        split=0.67
        loadDataset('iris.data',split,trainingset,testset)
        print('Training set :'+repr(len(trainingset)))
        print('Test set :'+repr(len(testset)))
        
        predictions=[]
        k=10
        
        for i in range(len(testset)):
                neighbours=getNeighbour(testset[i],trainingset,k)
                result=getResponse(neighbours)
                predictions.append(result)
                print('predicted: '+repr(result)+' actual: '+repr(testset[i][-1]))
                
        accuracy = getAccuracy(predictions,testset)
        print('Accuracy is: '+ repr(accuracy)+' %')
        
main()
