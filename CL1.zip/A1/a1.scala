object a1{
	def main(args:Array[String])
	{
		println("Enter number of elements")
		var n:Int = Console.readInt
		println("Enter the elements")
		
		var arr = new Array[Int](n)
		for(i<-0 to n-1)
		{
			arr(i) = Console.readInt
		}

		arr=arr.sorted
		for(j<-0 to n-1)
		{
			println(arr(j))
		}
		
		println("Enter the element to search")
		var search:Int = Console.readInt

		var start:Int = 0
		var end:Int = arr.length-1
		var index:Int = binarysearch(arr, start, end, search)
		if(index>0)
		{
			println("The index is", index)
		}
		else
		{
			println("Element not found")
		}


	}

	def binarysearch( list:Array[Int],  start:Int,  end:Int,  search:Int):Int=
	{
		var mid:Int = start + ((end-start)/2) 
		println(start, end, search)

		if(start<=end)
		{
			if(list(mid) == search)
			{
				return mid
			}
			else if(list(mid) < search)
			{
				return binarysearch(list, mid+1, end, search)
			}
			else
			{
				return binarysearch(list, start, mid-1, search)
			}
		}
		else
			return -1

	}
}
