object binarysearch
{

def search(nos:Array[Int],srno:Int,l:Int,r:Int) :Int=

{
	var mid:Int=(l+r)/2
	if(l>r)
		{
			return -1;
		}
	else if(nos(mid)==srno)
		{	
			return mid
		}
	else if(nos(mid)>srno)
		{
			search(nos,srno,l,mid-1)
		}
	else 
		{
			search(nos,srno,mid+1,r)
		}
}

def main(args:Array[String])
	{

	println("Enter the number of elements in the array")
	var n:Int=Console.readInt
	var nos= new Array[Int](n)
	println("Enter elements in the array")
	for(i <- 0 to n-1)
	{
	nos(i)=Console.readInt
	}
	nos=nos.sorted
	
	println("Enter element to be searched :")
	var srno:Int=Console.readInt

	var position:Int=search(nos,srno,0,n-1)

	if(position == -1)
	{
	println("Number not found")
	}
	else
	{
		println("Element found at position " +(position+1)+ " done")
	}
	
	}

}
