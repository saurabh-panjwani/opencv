import numpy as np
from matplotlib import pyplot as p
import cv2


src=cv2.imread("Lenna.png",0)
ret, thresh1=cv2.threshold(src,127,255,cv2.THRESH_BINARY)
ret, thresh2=cv2.threshold(src,127,255,cv2.THRESH_BINARY_INV)
ret, thresh3=cv2.threshold(src,127,255,cv2.THRESH_TRUNC)


thresh4=cv2.adaptiveThreshold(src,255,cv2.ADAPTIVE_THRESH_MEAN_C,cv2.THRESH_BINARY,11,2)
thresh5=cv2.adaptiveThreshold(src,255,cv2.ADAPTIVE_THRESH_GAUSSIAN_C,cv2.THRESH_BINARY,11,2)

titles=["Binary","Binary Inverted" ,"Truncated" ,"Adaptive Mean Threshold" ,"Adaptive Gaussian Threshold"]
images=[thresh1,thresh2,thresh3,thresh4,thresh5]

for i in xrange(5):
	p.subplot(2,3,i+1),p.imshow(images[i],'gray')
	p.title(titles[i])
	p.xticks([]),p.yticks([])
p.show()
