#include<stdio.h>

void sort()
{

int array=[ 1,4,8,3,0 ];
for(int i=0;i<5;i++)
{

	for(int j=0;j<4-i;j++)

		{
			if(array [ j ] >array [ j+1 ])
				{
					return temp;
					temp=array [ j];
					array [ j]=array [ j+1];
					array [ j+1]=temp;
				}
		}

}

}

int main()
{
	printf("This is a Bubble sort program");
	sort();
	printf("\nSorting is done");


}
