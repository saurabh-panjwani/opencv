#include"opencv2/opencv.hpp" 
#include<iostream>

using namespace std;
using namespace cv;

int main()

{

Mat src;
src=imread("Lenna.png",CV_LOAD_IMAGE_COLOR);
namedWindow("Source Image",CV_WINDOW_AUTOSIZE);
imshow("Source Image",src);

cvtColor(src,src,CV_BGR2GRAY);
namedWindow("Gray Image",CV_WINDOW_AUTOSIZE);
imshow("Gray Image",src);


//calculate normal histogram
int size=src.rows*src.cols;
Mat hist=Mat::zeros(1,256,CV_32SC1);
for(int i=0;i<256;i++)
	for(int j=0;j<256;j++)
		hist.at<int>((int)src.at<uchar>(i,j))+=1;



//calculate histogram using non opencv functions

float sum=0.0;
float freq[256];

Mat eq_hist=Mat::zeros(1,256,CV_32SC1);

for(int i=0;i<256;i++)
{

	freq[i]=(float)(hist.at<int>(i))/(float)size;
	sum+=freq[i];
	freq[i]=(float)255*sum;
	eq_hist.at<int>((int)freq[i])+=hist.at<int>(i);


}	

//calculate histogram using opencv functions
Mat eq_cv = Mat::zeros(1,256,CV_32SC1);
Mat eq_img;
equalizeHist(src,eq_img);

for(int i=0;i<eq_img.rows;i++)
	for(int j=0;j<eq_img.cols;j++)
		eq_cv.at<int>((int)eq_img.at<uchar>(i,j))++;





normalize(hist,hist,0,256,NORM_MINMAX,-1,Mat());
normalize(eq_hist,eq_hist,0,256,NORM_MINMAX,-1,Mat());
normalize(eq_cv,eq_cv,0,256,NORM_MINMAX,-1,Mat());

Mat canvas(300,256,CV_8UC1);
Mat canvas1(300,256,CV_8UC1);
Mat canvas2(300,256,CV_8UC1);


for(int i=0;i<256;i++)
	line(canvas,Point(i,299), Point(i,300-hist.at<int>(i)),255);
namedWindow("Original Histogram",CV_WINDOW_AUTOSIZE);
imshow("Original Histogram",canvas);




for(int i=0;i<256;i++)
	line(canvas1,Point(i,299), Point(i,300-eq_hist.at<int>(i)),255);
namedWindow(" Equilised Histogram",CV_WINDOW_AUTOSIZE);
imshow("Equilised Histogram",canvas1);

for(int i=0;i<256;i++)
	line(canvas2,Point(i,299),Point(i,300-eq_cv.at<int>(i)),255);

namedWindow(" Equilised Histogram using cv",CV_WINDOW_AUTOSIZE);
imshow("Equilised Histogram using cv",canvas2);




waitKey(0);
return 0;
}

