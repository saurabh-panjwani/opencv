#include<iostream>
#include<omp.h>

using namespace std;
int k=0;
class quicksort
{

public:
	int i,length,*array;
	void input();
	void display();
	void sort(int[],int,int);
	int partition(int[],int,int);



};


void quicksort::input()
{

cout<<"Enter number of elements in array"<<endl;
cin>>length;
array=new int[length];
cout<<"Enter elements in the array"<<endl;
for(int i=0;i<length;i++)
	cin>>array[i];

}

void quicksort::display()
{

cout<<"Sorted elements are:"<<endl;
for(int i=0;i<length;i++)
	cout<<array[i];

}

void quicksort::sort(int *array,int l,int r)


{

if(l<r)
	{
	int q=partition(array,l,r);
	cout<<"Pivot element with index "<<q<<" has been found out by thread "<<k<<"\n";
	#pragma omp parallel sections
		{
			#pragma omp section
			{
				//int thread_id=omp_get_thread_num();
				//cout<<"Left elements processed by thread"<<thread_id<<endl;
				 k=k+1;				
				sort(array,l,q-1);
			}

			#pragma omp section
			{
			//int thread_id1=omp_get_thread_num();
			//cout<<"Right elements processed by thread"<<thread_id1<<endl;
			 k=k+1;
			sort(array,q+1,r);
			
			}

	
	}


}

}


int quicksort::partition(int *array,int l,int r)
{

int i=l-1;
int key=r;
for(int j=l;j<r;j++)
{

	if(array[j]<=array[key])
		{
			i++;
			int temp;
			temp=array[i];
			array[i]=array[j];
			array[j]=temp;
			

		}
}
int temp2;
temp2=array[i+1];
array[i+1]=array[key];
array[key]=temp2;
return (i+1);

}


int main()
{
	quicksort obj;
	obj.input();
	obj.sort(obj.array,0,obj.length-1);
	obj.display();	
	return 0;
}


