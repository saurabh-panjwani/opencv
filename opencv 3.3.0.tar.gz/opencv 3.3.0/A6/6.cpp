#include "opencv2/opencv.hpp"
#include "iostream"
using namespace std;
using namespace cv; 

class Hist 
{ 
    Mat src, dst; 
    int hist[256]; 
    int max; 

public: 
    Hist(); 
    void calcHist(); 
    void dispHist(); 
}; 

Hist :: Hist() 
{ 
    src = imread("Lenna.png", CV_LOAD_IMAGE_GRAYSCALE); 
    if(!src.data) 
        cout<<"Error opening file.\n"; 
    namedWindow("Src Image", CV_WINDOW_AUTOSIZE); 
    imshow("Src Image", src); 
    dst = Mat(500, 256, CV_8UC1, Scalar::all(0)); 
    for(int i = 0; i < 256; i++) 
        hist[i] = 0; 
    max = 0; 
} 

void Hist :: calcHist() 
{ 
    for(int i = 0; i < src.rows; i++) 
		for(int j = 0; j < src.cols; j++) 
		{ 
		    hist[(src.at<uchar>(j, i))]++; 
		    if(hist[(src.at<uchar>(j, i))] > max) 
		        max = hist[(src.at<uchar>(j, i))]; 
		} 
} 

void Hist :: dispHist() 
{ 
    for(int i = 0; i < 255; i++) 
	{ 
	    hist[i] = (hist[i]*400)/max; 
	} 
    for(int i = 0; i < 255; i++) 
        line(dst, Point(i+1, 500-hist[i+1]), Point(i, 500-hist[i]), 255); 
    namedWindow("Histogram", CV_WINDOW_AUTOSIZE); 
    imshow("Histogram", dst); 
    waitKey(0); 
} 

int main() 
{ 
    Hist h; 
    h.calcHist(); 
    h.dispHist(); 
    return 0; 
} 
