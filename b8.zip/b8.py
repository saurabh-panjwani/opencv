import xml.etree.ElementTree as ET

tree = ET.parse("parsing_table.xml")
root = tree.getroot()

terminals = []
nonterminals = []

lproductions = []
rproductions = []

numberStates = 0

for child in root:
	if child.tag == "states":
		numberStates = int(child.text)
	elif child.tag == "term":
		terminals.append(child.text)
	elif child.tag == "nonterm":
		nonterminals.append(child.text)
	elif child.tag == "productions":
		for ch in child:
			lproductions.append(ch[0].text)
			rproductions.append(ch[1].text)
	elif child.tag == "actiontable":
		actions = [[] for x in range(numberStates)]
		i = 0
		for ch in child:
			for c in ch:
				actions[i].append(c.text)
			i+=1
	elif child.tag == "gototable":
		goto = [[] for x in range(numberStates)]
		i = 0
		for ch in child:
			for c in ch:
				goto[i].append(c.text)
			i+=1

nterms = len(terminals)
nnterms = len(nonterminals)
nprod = len(lproductions)

print("terminals")
print(terminals)

print("nonterminals")
print(nonterminals)

print("productions")
for i in range(nprod):
	print(lproductions[i]+"->"+rproductions[i])

print("Action table")
for i in actions:	
	print(i)

print("Goto table")
for i in goto:
	print(i)

#==========actual code starts here==================#


while True:
	string = input("Enter string: ")
	stringPointer = 0

	stack = ['$', 0]
	while True:
		print("\nstack: "+repr(stack))

		stackTop = stack[-1]
		stringSymbol = string[stringPointer]

		stringIndex = terminals.index(stringSymbol)

		action = actions[stackTop][stringIndex]
		print("action for stackTop: "+repr(stackTop)+" and stringSymbol: "+ repr(stringSymbol) + "is: "+ repr(action))

		if action == "Error":
			print(SyntaxError("error"))
			break
		elif action == "Accept":
			print("correct string")
			break
		elif "s" in action:
			stack.append(stringSymbol)
			number = action.replace("s","")
			stack.append(int(number))	
			stringPointer+=1
		elif "r" in action:
			productionIndex = int(action.replace("r", "")) - 1 
 
			for i in range(2*len(rproductions[productionIndex])):
				stack.pop()
			#adding element or rproductions
			stack.append(lproductions[productionIndex])
			productionState = stack[-2]
			ntindex = nonterminals.index(lproductions[productionIndex])
			nstate = goto[productionState][ntindex]
			stack.append(int(nstate))
			print("stack at reduce loop is: "+repr(stack))