import xml.etree.ElementTree as ET

tree = ET.parse("abc.xml")
root = tree.getroot()

terminals = []
nonterminals = []
left_production = []
right_production = []

numberofstates = 0

for child in root:
	if(child.tag == "states"):
		numberofstates = int(child.text)
	elif(child.tag == "term"):
		terminals.append(child.text)
	elif child.tag == "nonterm":
		nonterminals.append(child.text)
	elif child.tag == "production":
		for ch in child:
			left_production.append(ch[0].text)
			right_production.append(ch[1].text)
	elif child.tag == "actions":
		actions = [[] for x in range(numberofstates)]
		i=0
		for ch in child:
			for c in ch:
				actions[i].append(c.text)
			i = i+1
	elif child.tag == "gototable":
		goto = [[] for x in range(numberofstates)]
		i = 0
		for ch in child:
			for c in ch:
				goto[i].append(c.text)
			i = i+1


no_prod = len(left_production)
print("No of production: " + repr(no_prod))

print("Terminals: ");
print(terminals)

print("Non Terminals: ");
print(nonterminals)

print("production rules: ")
for i in range(no_prod):
	print(left_production[i] +"->"+ right_production[i])


print("Action Table:")
for i in actions:
	print(i)

print("Goto Table: ")
for j in goto:
	print(j)

while True:
	string = raw_input("Enter input String: ")
	string_ptr = 0

	stack = ['$',0]

	while True:
		print("Stack: " + repr(stack))
		stack_top = stack[-1]
		string_symbol = string[string_ptr]
		index = int(terminals.index(string_symbol))

		action = actions[int(stack_top)][index]
		print("Action for Stack top "+ repr(stack_top) + " with String Symbol "+ repr(string_symbol) + " is " + repr(action))

		if action == "Error":
			print("Syntax Error")
			break
		elif action == "accept":
			print("String Accepted..!!")
			break

		elif "S" in action:
			stack.append(string_symbol)
			number = action.replace("S"," ")
			stack.append(int(number))
			string_ptr += 1
			# print("Stack: " + repr(stack))
		
		elif "R" in action:
			production_index = int(action.replace("R", "")) - 1
			print("Reduction using " + left_production[production_index] + " -> " + right_production[production_index])

			for i in range(2*len(right_production[production_index])):
				stack.pop()

			stack.append(left_production[production_index])
			st  = stack[-2]
			loc = nonterminals.index(stack[-1])
			got = goto[st][loc]
			stack.append(got)

			print("Stack after reduction " + repr(stack))










