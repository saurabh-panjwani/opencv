#include <stdio.h>
#include <iostream>
#include <stdlib.h>

main()
{
int a,b,c;
printf("Hello");
int d,e;
printf("Hi");
a=b+20;
if()
{
int d,e;
d=e*20;
}
}


