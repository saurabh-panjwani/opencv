object binaryseach
{
def main(args:Array[String])
{
	println("Enter number of elements")
	var n:Int=Console.readInt
	var nos=new Array[Int](n)
	println("Enter elements")
	for (i<-0 to n-1)
	{
		nos(i) = Console.readInt
	}
	nos=nos.sorted
	println("Enter the element to be seached")
	var srno:Int=Console.readInt
	var position:Int= search(nos,srno,0,n-1)
	if (position == -1)
	{
		println("Element not found")
	}
	else
	{
		println("Element found at "+(position+1))
	}
}

def search(nos:Array[Int],srno:Int,l:Int,r:Int) :Int=
{
	var mid:Int=(l+r)/2
	if(l>r)
	{
		return -1;
	}
	else if(nos(mid)==srno)
	{
		return mid
	}
	else if(nos(mid)>srno)
	{
		search(nos,srno,l,mid-1)
	}
	else
	{
		search(nos,srno,mid+1,r)
	}
}
}	
