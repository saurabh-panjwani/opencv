#include <iostream>
#include <omp.h>

using namespace std;

int k=0;

class quick
{
	int n;
	int v[100];
public:
	quick()
	{
	
	}
	void getip();
	int partition(int v[],int l, int h);
	void quicksort(int v[],int l, int h);
	void sort();
	void display();
};

int main()
{
	quick q;
	q.getip();
	q.sort();
	q.display();
	return 0;
}

void quick::getip()
{
	cout<<"Enter length."<<endl;
	cin>>n;
	cout<<"Enter Elements."<<endl;
	for(int j=0;j<n;j++)
	{
		cin>>v[j];
	}
}

void quick::sort()
{
	quicksort(v,0,n-1);
}

void quick::display()
{
	for (int i=0;i<n;i++)
		cout<<v[i]<<"\n";
}

int quick::partition(int v[],int l,int h)
{
	int pivot,i,j,temp;
	pivot=v[l];
	i=l+1;
	j=h;
	
	while (1)
		{
			while(i<h && pivot>=v[i]) i++;
			while (pivot < v[j]) j--;

			if(i<j)
			{
				temp=v[i];
				v[i]=v[j];
				v[j]=temp;
			}
			else
			{
				v[l]=v[j];
				v[j]=pivot;
				return j;
			}
		}
}

void quick::quicksort(int v[],int l, int h)
{
	int j,tid=k;
	if (l<h)
	{
		cout<<"Thread "<<tid<<" on ("<<l<<","<<h<<")"<<endl;
		j=partition(v,l,h);
		cout<<"Pivot with index "<<j<<" has been found by Thread "<<tid<<endl;
		#pragma omp parallel sections
		{
			#pragma omp section
			{
				k++;
				quicksort(v,l,j-1);
			}
			#pragma omp section
			{
				k++;
				quicksort(v,j+1,h);
			}
		}	
	}
}
