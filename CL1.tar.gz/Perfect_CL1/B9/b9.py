from math import sqrt,log
from collections import Counter
from operator import itemgetter

def idf(word,allDocuments):
        numofdocswiththisword=0
        for document in allDocuments:
                if word in document:
                        numofdocswiththisword+=1
        if numofdocswiththisword:
                return round(log(float(float(len(allDocuments))/float(numofdocswiththisword)),2),3)
        else:
                return 0
                

def tf(word,file):
        return file.count(word)
        

def calculate_tfidf(word,testfile,clean_filecontents):
        return tf(word,testfile)*idf(word,clean_filecontents)
        

def lengthof(file,unq_words,clean_filecontents):
        val=0
        for word in unq_words:
                val+=pow(calculate_tfidf(word,file,clean_filecontents),2)
        return sqrt(val)
        
       
def cosineSimilarity(testfile,trainfile,unique_words,clean_filecontents):
        a=0
        b=lengthof(testfile,unique_words,clean_filecontents)*lengthof(trainfile,unique_words,clean_filecontents)
        for words in unique_words:
                a+=calculate_tfidf(words,testfile,clean_filecontents)*calculate_tfidf(words,trainfile,clean_filecontents)
        if not b:
                return 0
        else:
                return round(a/b,3)
                
                
def main():
        documents = ["doc1.txt","doc2.txt","doc3.txt","doc4.txt","doc5.txt","doc6.txt"]
        dataset = [["doc1.txt","science"],["doc2.txt","science"],["doc3.txt","science"],["doc4.txt","sports"],["doc5.txt","sports"],["doc6.txt","sports"]]
     
        filecontents = []
     
        for file in documents:
                filecontents.append(open(file,'r').read())
                
        clean_filecontents = []
        
        for i in filecontents:
                clean_filecontents.append(i.lower().rstrip("\n"))
        
        unique_words = []
        
        for i in clean_filecontents:
                unique_words+=i.split()
                
        testfilename = raw_input("Enter test file\n")
        testfile = open(testfilename,"r").read().lower()
        
        count=0
        
        for trainfile in clean_filecontents:
                dataset[count] += [cosineSimilarity(testfile,trainfile,unique_words,clean_filecontents)]
                count += 1
                
        k = 3
        
        sorted_dataset = sorted(dataset,key=itemgetter(2),reverse=True)
        
        top_k=sorted_dataset[:k]
        
        print top_k
        
        top_k[:] = (x for x in top_k if x[2]!=0)
        
        if len(top_k):
                class_count = Counter(category for (document,category,value) in top_k)
                
                classification = max(class_count, key=lambda cls:class_count[cls])
                
                print "Class for test file is:"
                print classification
                
        else:
                print "Doesnot match"
                
main()
