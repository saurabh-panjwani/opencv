#include<iostream>

using namespace std;

struct dag_tree
{
	int label;
	char data;
	struct dag_tree *left,*right;
};
typedef dag_tree node;

class Dag
{
	int R[10];
	int top;
	char *op_name;

public:
	void Initialize(node *root);
	void CreateNode(node **root,char val);
	void Insert(node **root,char val);
	void FindLeafNodeLabel(node *root,int val);
	void FindInteriorNodeLabel(node *root);
	void NameOfOperation(char ch);
	void PrintInorder(node *root);
	void push(int val);
	int pop();
	void swap();
	void GenerateCode(node *root);
};

void Dag::Initialize(node *root)
{
	top = root->label-1;
	int temp = top;
	for(int i=0;i<=top;i++)
	{
		R[i] = temp;
		temp--;
	}
}

void Dag::CreateNode(node **root,char val)
{
	if(!(*root))
	{
		node *temp = (node*)malloc(sizeof(node));
		temp->left  = NULL;
		temp->right = NULL;
		temp->label = -1;
		temp->data = val;
		*root = temp;
	}
}

void Dag::Insert(node **root,char val)
{
	char leftchild,rightchild;
	int no_of_child;
	CreateNode(root,val);
	cout<<"Enter no of Childerens of "<<val<<": ";
	cin>>no_of_child;

	if(no_of_child==2)
	{
		cout<<"\nEnter Left Child of "<<val<<": ";
		cin>>leftchild;
		CreateNode(&(*root)->left,leftchild);
		cout<<"\nEnter Right Child of "<<val<<": ";
		cin>>rightchild;
		CreateNode(&(*root)->right,rightchild);
		Insert(&(*root)->left,leftchild);
		Insert(&(*root)->right,rightchild);
	}
}

void Dag::FindLeafNodeLabel(node *root,int val)
{
	if(root->left !=NULL && root->right !=NULL)
	{
		FindLeafNodeLabel(root->left,1);
		FindLeafNodeLabel(root->right,0);
	}	
	else
		root->label = val;
}

void Dag::FindInteriorNodeLabel(node *root)
{
	if(root->left->label==-1)
		FindInteriorNodeLabel(root->left);
	else if(root->right->label==-1)
		FindInteriorNodeLabel(root->right);
	else
	{
		if(root->left != NULL && root->right != NULL)
		{
			if(root->left->label==root->right->label)
				root->label = root->left->label + 1;
			else
			{
				if(root->left->label>root->right->label)
					root->label=root->left->label;
				else
					root->label = root->right->label;
			}
		}
	}
}

void Dag::NameOfOperation(char ch)
{
	switch(ch)
	{
		case '+':
			op_name = (char*)"ADD";
			break;
		case '-':
			op_name = (char*)"SUB";
			break;
		case '*':
			op_name = (char*)"MUL";
			break;
		case '/':
			op_name = (char*)"DIV";
			break; 
	}
}

void Dag::PrintInorder(node *root)
{
	if(root)
	{
		PrintInorder(root->left);
		cout<<root->data<<" with label "<<root->label<<endl;
		PrintInorder(root->right);
	}
}

int Dag::pop()
{
	int temp = R[top];
	top--;
	return temp;
}

void Dag::push(int val)
{
	top++;
	R[top] = val;
}

void Dag ::swap()
{
	int temp = R[0];
	R[0] = R[1];
	R[1] = temp;
}

void Dag::GenerateCode(node *root)
{
	if(root->left!=NULL && root->right!=NULL)
	{
		if(root->left->label==1 && root->right->label==0 && root->left->left==NULL && root->left->right==NULL && root->right->left==NULL && root->right->right==NULL)
		{
			cout<<"MOV "<<root->left->data<<" R["<<R[top]<<"]"<<endl;
			NameOfOperation(root->data);
			cout<<op_name<<" "<<root->right->data<<" R["<<R[top]<<"] "<<endl;
		}

		else if(root->left->label>=1 && root->right->label==0)
		{
			GenerateCode(root->left);
			NameOfOperation(root->data);
			cout<<op_name<<" "<<root->right->data<<" R["<<R[top]<<"] "<<endl;
		}

		else if(root->left->label>=root->right->label)
		{
			int temp;
			GenerateCode(root->left);
			temp = pop();
			GenerateCode(root->right);
			push(temp);
			NameOfOperation(root->data);
			cout<<op_name<<" R["<<R[top-1]<<"] "<<" R["<<R[top]<<"]"<<endl;
		}
		else if(root->right->label>root->left->label)
		{
			int temp;
			swap();
			GenerateCode(root->right);
			temp = pop();
			GenerateCode(root->left);
			push(temp);
			swap();
			NameOfOperation(root->data);
			cout<<op_name<<" R["<<R[top-1]<<"] "<<" R["<<R[top]<<"]"<<endl;
		}
	}
	else if(root->left == NULL && root->right == NULL && root->label == 1)
				cout << "MOV " << root->data << ",R[" << R[top] << "]\n";
}

int main()
{
	node *root = NULL;
	char ch;
	cout<<"Enter Root For Dag: ";
	cin>>ch;
	Dag obj;
	obj.Insert(&(root),ch);
	obj.FindLeafNodeLabel(root,1);

	while(root->label==-1)
		obj.FindInteriorNodeLabel(root);

	obj.Initialize(root);
	cout<<"Inorder of Dag Tree"<<endl;
	obj.PrintInorder(root);
	cout<<"Intermidiate Code: "<<endl;
	obj.GenerateCode(root);
	return 0;
}